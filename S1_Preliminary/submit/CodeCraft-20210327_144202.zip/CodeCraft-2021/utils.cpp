#include "utils.h"

std::vector<Machine*>* cpuOrder(std::vector<Machine*>& m) {
	std::vector<Machine*>* copyMachine = new std::vector<Machine*>(m);
	std::sort(copyMachine->begin(), copyMachine->end(), [](Machine* ls, Machine* rs) {return ls->cpuPri() < rs->cpuPri(); });
	return copyMachine;
}

std::vector<Machine*>* memoryOrder(std::vector<Machine*>& m) {
	std::vector<Machine*>* copyMachine = new std::vector<Machine*>(m);
	std::sort(copyMachine->begin(), copyMachine->end(), [](Machine* ls, Machine* rs) {return ls->memoryPri() < rs->memoryPri(); });
	return copyMachine;
}

std::vector<VM*>* cpuOrder(std::vector<VM*>& m) {
	std::vector<VM*>* copyMachine = new std::vector<VM*>(m);
	std::sort(copyMachine->begin(), copyMachine->end(), [](VM* ls, VM* rs) {return ls->cpuPri() > rs->cpuPri(); });
	return copyMachine;
}

std::vector<VM*>* memoryOrder(std::vector<VM*>& m) {
	std::vector<VM*>* copyMachine = new std::vector<VM*>(m);
	std::sort(copyMachine->begin(), copyMachine->end(), [](VM* ls, VM* rs) {return ls->memoryPri() > rs->memoryPri(); });
	return copyMachine;
}

void MoneySort(std::vector<RunMachine*>& m) {
	std::sort(m.begin(), m.end(), [](RunMachine* ls, RunMachine* rs) {return ls->getMoney() < rs->getMoney(); });
}

void ResourceSort(std::vector<RunMachine*>& m) {
	std::sort(m.begin(), m.end(), [](RunMachine*& ls,RunMachine*& rs) {
		return ls->getResourceSortCoef() < rs->getResourceSortCoef();
		});
}


void spceResourceSort(std::vector<RunMachine*>& m) {
	std::sort(m.begin(), m.end(), [](RunMachine* ls, RunMachine* rs) {
		return ls->getSapceResourceSortCoef() < rs->getSapceResourceSortCoef();
		});
}

void RspceResourceSort(std::vector<RunMachine*>& m) {
	std::sort(m.begin(), m.end(), [](RunMachine* ls, RunMachine* rs) {
		return ls->getSapceResourceSortCoef() > rs->getSapceResourceSortCoef();
		});
}

void IDSort(std::vector<RunMachine*>& m) {
	std::sort(m.begin(), m.end(), [](RunMachine* ls, RunMachine* rs) {
		return ls->getID() < rs->getID();
		});
}

void IDSort(std::vector<Request*>& m) {
	std::sort(m.begin(), m.end(), [](Request* ls, Request* rs) {
		return ls->getID() < rs->getID();
		});
}

void SpaceSort(std::vector<Request*>& m) {
	std::sort(m.begin(), m.end(), [](Request* ls, Request* rs) {
		return ls->getSpace() > rs->getSpace();
		});
}

void runVMNumSort(std::vector<RunMachine*>& m) {
	std::sort(m.begin(), m.end(), [](RunMachine* ls, RunMachine* rs) {
		return ls->getRunNums() < rs->getRunNums();
		});
}

void RrunVMNumSort(std::vector<RunMachine*>& m) {
	std::sort(m.begin(), m.end(), [](RunMachine* ls, RunMachine* rs) {
		return ls->getRunNums() > rs->getRunNums();
		});
}


int getMaxnum(std::vector<RunMachine*> a) {
	int temp = 0;
	for (auto it : a)
		temp += it->getperfetctNum();
	return temp;
}

int getRunningnum(std::vector<RunMachine*> a) {
	int temp = 0;
	for (auto it : a)
		temp += it->getRunNums();
	return temp;
}

int binnarySearch(std::vector<Request*>&r,int ID) {
	int start = 0, end = r.size();
	if (!end) return -1;
	int middle;
	while (start <= end) {
		middle = (start + end) / 2;
		if (r[middle]->getID() == ID) return middle;
		else if (r[middle]->getID() > ID) end = middle - 1;
		else start = middle + 1;
	}
	return -1;
}

int binnarySearch(std::vector < RunMachine* >r, Request*find) {
	int start = 0, end = r.size();
	if (!end) return -1;
	double coef = find->getSpace();
	if (find->isDouble()) coef /= 2.0;
	int middle = 0;
	double resourceceof;
	while (start <= end) {
		middle = (start + end) / 2;
		resourceceof = r[middle]->getSapceResourceSortCoef();
		if (resourceceof==coef) return middle;
		else if (resourceceof > coef) end = middle - 1;
		else start = middle + 1;
	}
	return middle;
}

long long dayCost()
{
	long long temp = 0;
	for (auto it : Runs) {
		if (it->getRunNums())
			temp += it->getRunMoney();
	}
	return temp;
}

int allMachineMoney() {
	int temp = 0;
	for (auto it : Runs) {
		temp += it->getMoney();
	}
	return temp;
}

void disPlayRunning(std::vector<RunMachine*>&r) {
	for (int i = 0; i < r.size(); i++)
		std::cout << i << " " << *(r[i]) << std::endl;
}
