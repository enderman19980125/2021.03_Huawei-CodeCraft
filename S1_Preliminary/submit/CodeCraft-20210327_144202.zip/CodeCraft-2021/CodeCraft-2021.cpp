#include <iostream>
#include <fstream>
#include <string>
#include "FileHundle.h"
#include "Bean.h"
#include "algo.h"

using namespace std;

void repeat() {
	map<int, int>mp;
	for (auto& it : Runs) {
		for (int i = 0; i < it->getRunNums(); i++) {
			auto p = it->getVMByIndex(i).second;
			if (mp[p->getID()]) {
				cout <<"reapet"<< p->getID() << endl;
				exit(0);
			}
			else mp[p->getID()]++;
		}
	}
}

int main() {
#if 0

	Machine a;
	cin >> a;
	cout << a.cpuPri() << " " << a.memoryPri() << " " << a;
#endif
	std::ifstream in("training-2.txt"); //training-1.txt example.txt
	Hundle(cin);
#if 0
	vector<Machine*>mcpuOrder = *cpuOrderMachines;
	for (auto it : mcpuOrder) {
		cout << *it << endl;
	}
	cout << "memory" << endl;
	vector<Machine*>mmemoryOrder = *memoryOrderMachines;
	for (auto it : mmemoryOrder) {
		cout << *it << endl;
	}
#endif
#if 0
	vector<VM*>mcpuOrder = *cpuOrderVMs;
	for (auto it : mcpuOrder) {
		cout << *it << endl;
	}
	cout << "memory" << endl;
	vector<VM*> mmemoryOrder = *memoryOrderVMs;
	for (auto it : mmemoryOrder) {
		cout << *it << endl;
	}
#endif
#if 0
	auto a = Requests[0];
	for (auto i = a.begin(); i != a.end(); i++) {
		cout << **i << " " << (**i).getCoef() << endl;
	}

#endif
#if 0
	vector<RunMachine*>Runs;
	for (auto it : Machines)
		Runs.push_back(RunMachine::build(it));
	disPlayRunning(Runs);
	Request r;
	while (cin >> r)
	{
		cout << r << endl;
		Runs[1]->update(r);
		disPlayRunning(Runs);
		cout << Runs[0]->getResourceSortCoef() << " " << Runs[1]->getResourceSortCoef() << endl;
		cout << "sorted\n";
		ResourceSort(Runs);
		disPlayRunning(Runs);
	}
#endif
#if 0
	Request r, r1;
	cin >> r;
	cout << r << endl;
	addVirtualRequest(&r);
	disPlayRunning(Runs);
	cout << "sorted\n";
	ResourceSort(Runs);
	disPlayRunning(Runs);
	cin >> r1;
	cout << r1 << endl;
	addVirtualRequest(&r1);
	disPlayRunning(Runs);
	cout << "sorted\n";
	ResourceSort(Runs);
	disPlayRunning(Runs);

#endif
#if 1
	//vali();
#endif
#if 1

	Runs.reserve(10000);
	sort(Machines.begin(), Machines.end(), [](Machine* ls, Machine* rs) {return ls->getMoney() < rs->getMoney(); }); // not all
	//long long cost = 0;
	for (int i = 0; i < DataNum; i++) {
		hundleRequest_2(Requests[i]);
		output(Requests[i]);
		nowday++;
		//repeat();
		//cost += dayCost();
		//cout << i + 1 << "money " << cost + allMachineMoney()<<str_format(" run Money:%d buy:%d",cost,(int)allMachineMoney()) << endl;
		//disPlayRunning(Runs);
	}
	//cost += allMachineMoney();
	//cout << cost << endl;
#endif
#if 0
	for (int i = 0; i < DataNum; i++) {
		for (int j = 0; j < Requests[i].size(); j++) {
			cout << Requests[i][j]->getID() << " " << VMID2RunerMachineID[Requests[i][j]->getID()].first << endl;
			if (VMID2RunerMachineID.count(Requests[i][j]->getID()) != 1) {
				cout << "error\n";
				cout << i << " " << j << " " << Requests[i][j]->getID();
				getchar();
			}
		}
	}
#endif
	cout.flush();
	return 0;
}