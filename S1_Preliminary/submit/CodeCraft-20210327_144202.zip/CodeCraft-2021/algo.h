#ifndef algo
#define algo
#include <map>
#include <cstring>
#include "FileHundle.h"
Machine* findMinforVM(Request* r);
extern std::map<int, std::pair<int, int>>VMID2RunerMachineID;  //vmid   machineID  A_or_B_or_Double
extern std::vector<RunMachine*>Runs;
extern int nowRealMachinesNum;
extern int nowday;
void addRequest(std::vector<Request*>& r);
void mergeVirtual(std::vector<RunMachine*>&);
void virtual2real(std::vector<RunMachine*>&);
void virtual2real_4(std::vector<RunMachine*>&);
void hundleRequest(std::vector<Request*>&);
void hundleRequest_2(std::vector<Request*>&);
int optimi(RunMachine*, int, RunMachine*, Request*);
void output(std::vector<Request*>&);
void move();
void move_2();
void move_3();
void move_4();
void move_5();
void move_6();
void mergeVirtual_2(std::vector<RunMachine*>&, std::vector<Request*>&, std::map<int, RunMachine*>&);
#endif // !algo
