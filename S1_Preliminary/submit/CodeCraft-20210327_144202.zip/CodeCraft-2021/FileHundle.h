#ifndef FileHundle
#define FileHundle
#include <string>
#include <fstream>
#include <vector>
#include <map>
#include <cstring>
#include <limits>
#include "Bean.h"
#include "utils.h"

int Hundle(std::istream &in);
extern int DataNum;
extern int MachineNum;
extern Machine* buffM;
extern int VMNum;
extern std::vector<std::vector<int>>afterMaxNums;
extern std::map<int,int>liveTime;
extern int buffMachine;
extern std::map<int, std::pair<int, int>>startEndTime;
extern std::vector<Machine*>Machines;
extern std::vector<VM*> VMs;
extern std::vector<Machine*>* cpuOrderMachines;
extern std::vector<Machine*>* memoryOrderMachines;
extern std::vector<VM*>* cpuOrderVMs;
extern std::vector<VM*>* memoryOrderVMs;
extern std::map<std::string, int>MachineName2Index;
extern std::map<int, std::string>Index2MachineName;
extern std::map<std::string, int>VMName2Index;
extern std::map<int, std::string>Index2VMName;
extern std::vector<std::vector<Request*>> Requests;
extern std::map<int, int>lessestMoneyMachine; // vm id index machine index ��ʡǮ��
extern std::map<int, int>perfectVMNUm; // ���ʺϵķż�̨
extern std::vector<std::vector<RunMachine*>>perfecRuns;
int getVMName2Index(std::string&);
int getVMName2Index(std::string&&);
extern std::vector<std::vector<ValueforMoney*> >Value;
void analys();
#endif
