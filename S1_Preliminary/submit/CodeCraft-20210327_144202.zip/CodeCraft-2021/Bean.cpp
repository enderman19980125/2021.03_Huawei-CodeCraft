#include "Bean.h"

#pragma warning(disable:4996)
Machine::Machine(){
	memset(name, 0, sizeof(name));
	cpuNum = memoryNum = money = runMoney  = 0;
	ID = 0x7fffffff;
}

Machine::Machine(char* name, int cpunum, int memorynum, int money, int runmoney) {
	strcpy(this->name, name);
	this->cpuNum = cpunum;
	this->memoryNum = memorynum;
	this->money = money;
	this->runMoney = runmoney;
	this->ID = 0x7fffffff;
}

std::ostream& operator<<(std::ostream& os, const Machine& m){
	os << m.name << " " << m.cpuNum << " " << m.memoryNum << " " << m.money << " " << m.runMoney;
	return os;
}


std::istream& operator>>(std::istream& is, Machine& m) {
	std::string temp;
	std::getline(is, temp);
	//std::cout << temp << std::endl;
	temp = &temp[1];
	//std::cout << temp << std::endl;
	temp.erase(temp.end() - 1);
	//std::cout << temp << std::endl;
	char* s = &temp[0];
	int flag = -1;
	while (s[++flag] != ',');
	s[flag] = ' ';
	sscanf(s, "%s", m.name);
	s = &s[flag];
	sscanf(s, "%d, %d, %d, %d", &m.cpuNum, &m.memoryNum, &m.money, &m.runMoney);
	m.ID = 0x7fffffff;
	return is;
}

Machine* Machine::build(std::string& ss){
	ss = &ss[1];
	//std::cout << temp << std::endl;
	ss.erase(ss.end() - 1);
	//std::cout << temp << std::endl;
	char*s = &ss[0];
	int flag = -1;
	char hostname[21];
	int cpunum;
	int memorynum;
	int money;
	int runmoney;
	while (s[++flag] != ',');
	s[flag] = ' ';
	sscanf(s, "%s", hostname);
	s = &s[flag];
	sscanf(s, "%d, %d, %d, %d", &cpunum, &memorynum, &money, &runmoney);
	return new Machine(hostname, cpunum, memorynum, money, runmoney);
}

double Machine::cpuPri()
{
	return (double)this->money / this->cpuNum;
}

double Machine::memoryPri()
{
	return (double)this->money / this->memoryNum;
}

int Machine::getRunMoney()
{
	return this->runMoney;
}

int Machine::getCpuNum()
{
	return this->cpuNum;
}

int Machine::getMemoryNum()
{
	return this->memoryNum;
}

std::pair<int, int> Machine::getCpuMemory()
{
	return std::make_pair(this->cpuNum, this->memoryNum);
}

int Machine::getMoney()
{
	return this->money;
}

int Machine::emptyIsOk(std::pair<int, int>&&rs)
{
	return (this->cpuNum / 2 )>= rs.first && (this->memoryNum / 2) >= rs.second;
}


std::string Machine::getName()
{
	return std::string(this->name);
}

int Machine::getID()
{
	return ID;
}

void Machine::setID(int t)
{
	this->ID = t;
}

VM::VM() {
	memset(name, 0, sizeof(name));
	cpuNum = memoryNum = isDouble = 0;
}

VM::VM(char* name, int cpunum, int memorynum, int isdouble) {
	strcpy(this->name, name);
	this->cpuNum = cpunum;
	this->memoryNum = memorynum;
	this->isDouble = isdouble;
}

std::ostream& operator<<(std::ostream& os, const VM& m) {
	os << m.name << " " << m.cpuNum << " " << m.memoryNum << " " << m.isDouble;
	return os;
}


std::istream& operator>>(std::istream& is, VM& m) {
	std::string temp;
	std::getline(is, temp);
	//std::cout << temp << std::endl;
	temp = &temp[1];
	//std::cout << temp << std::endl;
	temp.erase(temp.end() - 1);
	//std::cout << temp << std::endl;
	char* s = &temp[0];
	int flag = -1;
	while (s[++flag] != ',');
	s[flag] = ' ';
	sscanf(s, "%s", m.name);
	s = &s[flag];
	sscanf(s, "%d, %d, %d", &m.cpuNum, &m.memoryNum, &m.isDouble);

	return is;
}

VM* VM::build(std::string& ss) {
	ss = &ss[1];
	//std::cout << temp << std::endl;
	ss.erase(ss.end() - 1);
	//std::cout << temp << std::endl;
	char* s = &ss[0];
	int flag = -1;
	char hostname[21];
	int cpunum;
	int memorynum;
	int isdouble;
	while (s[++flag] != ',');
	s[flag] = ' ';
	sscanf(s, "%s", hostname);
	s = &s[flag];
	sscanf(s, "%d, %d, %d", &cpunum, &memorynum, &isdouble);
	return new VM(hostname, cpunum, memorynum, isdouble);
}

double VM::cpuPri()
{
	return (double)this->cpuNum / this->memoryNum;
}

double VM::memoryPri()
{
	return (double)this->memoryNum / this->cpuNum;
}

double VM::getCoef()
{
	return (double)this->memoryNum / this->cpuNum;
}

int VM::getDouble()
{
	return this->isDouble;
}

std::pair<int, int> VM::getCpuMemory()
{
	if (isDouble)
		return std::make_pair(this->cpuNum / 2, this->memoryNum / 2);
	return std::make_pair(this->cpuNum, this->memoryNum);
}

std::string VM::getName()
{
	return std::string(this->name);
}

std::ostream& operator<<(std::ostream& os, const Request& r)
{
	if (r.category == 0)
		os << "add " << r.VMName << " " << r.VMIndex << " " << r.ID << (r.isReal ? " real" : " virtual");
	else if (r.category == 1)
		os << "del " << r.ID;
	else
		return os;
	return os;
}

std::istream& operator>>(std::istream& is, Request& r)
{
	std::string temp;
	std::getline(is, temp);
	char* s;
	//std::cout << temp << std::endl;
	temp = &temp[1];
	//std::cout << temp << std::endl;
	temp.erase(temp.end() - 1);
	//std::cout << temp << std::endl;
	int addOrDel;
	if (temp[0] == 'a'){
		addOrDel = 0;
		s = &temp[5];
		int flag = -1;
		while (s[++flag] != ',');
		s[flag] = ' ';
		sscanf(s, "%s", r.VMName);
		s = &s[flag];
		r.VMIndex = getVMName2Index(r.VMName);
	}
	else {
		addOrDel = 1;
		s = &temp[5];
	}
	r.category = addOrDel;
	sscanf(s, " %d", &r.ID);
	r.isReal = 0;
	r.Double = VMs[r.VMIndex]->getDouble();
	return is;
}

std::ostream& operator<<(std::ostream& os, const RunMachine& m)
{
	os << m.name << " " << m.cpuNum << " " << m.memoryNum << " " << m.money << " " << m.runMoney << " freeCPU_A " << m.freeCPU_A \
		<<"  freeMemo_A "<<m.freeMemory_A << " freeCPU_B " << m.freeCPU_B<<" freeMemo_B "<<m.freeMemory_B << " old " << m.old;
	for (auto it : m.RunningVM)
		std::cout << "/ vmid " << it.first << " " << it.second->getID();
	return os;
}


#if 1
Request::Request()
{
	memset(this->VMName, 0, sizeof(this->VMName));
	this->category = -1;
	this->VMIndex = -1;
	this->ID = -1;
	this->isReal = 0;
	this->Double = -1;
}

Request::Request(char* s, int a, int b, int c)
{
	strcpy(this->VMName, s);
	this->category = a;
	this->VMIndex = b;
	this->ID = c;
	this->isReal = 0;
	this->Double = VMs[VMIndex]->getDouble();
}

int Request::getSum() {
	auto a = VMs[this->getVMIndex()]->getCpuMemory();
	auto temp = a.first + a.second;
	if (this->isDouble())
		temp *= 2;
	return temp;
}

Request* Request::build(std::string& ss)
{
	ss = &ss[1];
	//std::cout << temp << std::endl;
	ss.erase(ss.end() - 1);
	//std::cout << temp << std::endl;
	char* s;
	char hostname[21] = "";
	int VMIndex(0), ID;
	int addOrDel;
	if (ss[0] == 'a') {
		addOrDel = 0;
		s = &ss[5];
		int flag = -1;
		while (s[++flag] != ',');
		s[flag] = ' ';
		sscanf(s, "%s", hostname);
		s = &s[flag];
		VMIndex = getVMName2Index(hostname);
	}
	else {
		addOrDel = 1;
		s = &ss[5];
	}
	sscanf(s, " %d", &ID);
	return new Request(hostname, addOrDel, VMIndex, ID);
}


int Request::getVMIndex()
{
	return this->VMIndex;
}
int Request::setVMIndex(int a)
{
	return this->VMIndex = a;
}
int Request::isDouble()
{
	return Double;
}
int Request::getCategory()
{
	return this->category;
}

double Request::getSpace()
{
	double temp = 0.0;
	auto p = this->getCpuMemory();
	temp = ((double)p.first + p.second) / 2.0;
	if (this->isDouble()) {
		return temp * 2;
	}
	else return temp;
}
void Request::setIsReal()
{
	this->isReal = 1;
}
int Request::getIsReal()
{
	return this->isReal;
}
int Request::getID()
{
	return ID;
}

double Request::getCoef()
{
	return 	VMs[VMIndex]->getCoef();
}
std::pair<int, int> Request::getCpuMemory()
{
	return VMs[VMIndex]->getCpuMemory();
}
int Request::getMachineID()
{
	return MachineID;
}
void Request::setMachineID(int a)
{
	this->MachineID = a;
}
void Request::setType(int a)
{
	type = a;
}

int Request::getDel()
{
	return del;
}

void Request::setDel()
{
	del = 1;
}

void Request::setPerfectNum(int a)
{
	this->perfectNum = a;
}

int Request::getPerfectNum()
{
	return perfectNum;
}

int Request::getType() {
	return type;
}
#endif

RunMachine::RunMachine()
{
	memset(name, 0, sizeof(name));
	cpuNum = memoryNum = money = runMoney = freeCPU_A=freeCPU_B=freeMemory_A = freeMemory_B = old = 0;
}

RunMachine::RunMachine(Machine* m)
{
	strcpy(this->name, &(m->getName())[0]);
	this->cpuNum = m->getCpuNum();
	this->memoryNum = m->getMemoryNum();
	this->money = m->getMoney();
	this->runMoney = m->getRunMoney();
	this->freeCPU_A = this->freeCPU_B = this->cpuNum / 2;
	this->freeMemory_A = this->freeMemory_B = this->memoryNum / 2;
	this->old = 0;
}

RunMachine* RunMachine::build(Machine* m)
{
	return new RunMachine(m);
}

int RunMachine::getRunMoney()
{
	return this->runMoney;
}

int RunMachine::getMoney()
{
	return this->money;
}

int RunMachine::IsOk(Request*& r)
{
	auto&& p = r->getCpuMemory();
	auto d = r->isDouble();
	auto fA = freeCPU_A - p.first;
	auto fmA = freeMemory_A - p.second;
	auto fB = freeCPU_B - p.first;
	auto fmB = freeMemory_B - p.second;
	if (fA >= 0 && fmA >= 0) {
		if (d) {
			if (fB >= 0 && fmB >= 0)
				return 3;
			else return 0;
		}
		else  return 1;
	}
	else if (d)
		return 0;
	else if (fB >= 0 && fmB >= 0)
		return 2;
	return 0;
}

int RunMachine::update(Request* & r)
{
	auto flag = IsOk(r);
	if (!flag)return 0;
	auto p = r->getCpuMemory();
	if (r->isDouble()) {
		freeCPU_A -= p.first;
		freeCPU_B -= p.first;
		freeMemory_A -= p.second;
		freeMemory_B -= p.second;
		RunningVM.push_back(std::make_pair(3, r));
	}
	else if (flag == 2) {
		freeCPU_B -= p.first;
		freeMemory_B -= p.second;
		RunningVM.push_back(std::make_pair(2, r));
	}
	else {
		freeCPU_A -= p.first;
		freeMemory_A -= p.second;
		RunningVM.push_back(std::make_pair(1, r));
	}

	return flag;
}

int RunMachine::update(Request* r, int type)
{
	auto flag = type;
	if (!flag)return 0;
	auto p = r->getCpuMemory();
	if (r->isDouble() && type != 3) {
		std::cout << "error in update\n";
		exit(0);
	}
	if (type == 3) {
		if (freeCPU_A >= p.first && freeCPU_B >= p.first && freeMemory_A >= p.second && freeMemory_B >= p.second) {
			freeCPU_A -= p.first;
			freeCPU_B -= p.first;
			freeMemory_A -= p.second;
			freeMemory_B -= p.second;
			RunningVM.push_back(std::make_pair(3, r));
		}
		else return 0;
	}
	else if (flag == 2) {
		if (freeCPU_B >= p.first && freeMemory_B >= p.second) {
			freeCPU_B -= p.first;
			freeMemory_B -= p.second;
			RunningVM.push_back(std::make_pair(2, r));
		}
		else return 0;
	}
	else {
		if (freeCPU_A >= p.first && freeMemory_A >= p.second) {
			freeCPU_A -= p.first;
			freeMemory_A -= p.second;
			RunningVM.push_back(std::make_pair(1, r));
		}
		else return 0;
	}
#if 0
	if(freeCPU_A<0 || freeCPU_B<0 || freeMemory_A<0 || freeMemory_B<0)
	{
		std::cout << this->ID<<" error in free\n";

		for (int i = 0; i < Runs[ID]->getRunNums(); i++) {
			std::cout << Runs[ID]->getVMByIndex(i).second->getID() << " ";
		}
		exit(0);
	}
#endif
	return flag;
}

void RunMachine::Delete(Request* r , int t)
{

	r->setVMIndex(getVMByID(r->getID()).second->getVMIndex());
	//std::cout << r->getVMIndex()<<" "<<VMs[r->getVMIndex()]->getName() << std::endl;
	auto p = r->getCpuMemory();
	if (t == 1 || t==3) {
		freeCPU_A += p.first;
		freeMemory_A += p.second;
	}
	if (t == 2 || t == 3) {
		freeCPU_B += p.first;
		freeMemory_B += p.second;
	}
	for (auto it = RunningVM.begin(); it != RunningVM.end(); it++) {
		if (it->second->getID() == r->getID()) {
			RunningVM.erase(it);
			break;
		}
	}
}

int RunMachine::getCPUMemorySum()
{
	return freeCPU_A + freeCPU_B + freeMemory_A + freeMemory_B;
}

double RunMachine::getSapceResourceSortCoef() {
	return std::min(((double)freeCPU_A + freeMemory_A) / 2.0, ((double)freeCPU_B + freeMemory_B) / 2.0);
}

double RunMachine::getResourceSortCoef()
{
	return ((double)freeCPU_A + freeCPU_B) / cpuNum + ((double)freeMemory_A + freeMemory_B) / memoryNum;
}

int RunMachine::getOld()
{
	return old;
}

std::pair<int, Request*> RunMachine::getVMByIndex(int i)
{
	return this->RunningVM[i];
}

std::pair<int, Request*> RunMachine::getVMByID(int ID)
{
	for (int i = 0; i < RunningVM.size(); i++) {
		if (RunningVM[i].second->getID() == ID)
			return RunningVM[i];
	}
#ifdef __debug__
	std::cout << " error in getVMByID\n";
#endif // __debug__
	std::cout << " error in getVMByID\n";
	return std::pair<int, Request*>(); // error
}

void RunMachine::setOld()
{
	old = 1;
}

int RunMachine::getID()
{
	return ID;
}

void RunMachine::setID(int t)
{
	this->ID = t;
}

int RunMachine::getRunNums()
{
	return this->RunningVM.size();
}

void RunMachine::mySort()
{
	std::sort(RunningVM.begin(), RunningVM.end(), [](std::pair<int, Request*>ls, std::pair<int, Request*>rs) {
		return ls.second->getSum() > rs.second->getSum();
		});
}

void RunMachine::clear()
{
	this->RunningVM.clear();
	this->freeCPU_A = this->freeCPU_B = cpuNum / 2;
	this->freeMemory_A = this->freeMemory_B = memoryNum / 2;
}

std::pair<int, int> RunMachine::getABfree()
{
	return std::pair<int, int>(freeCPU_A + freeMemory_A, freeCPU_B + freeMemory_B);
}


int RunMachine::getperfetctNum()
{
	return this->perfetctNum;
}

void RunMachine::setperfetctNum(int pvm)
{
	this->perfetctNum = pvm;
}

int RunMachine::getMin()
{
	return std::min(freeCPU_A + freeMemory_A, freeCPU_B + freeMemory_B);
}

void RunMachine::setReal(int i)
{
	RunningVM[i].second->setIsReal();
}

double RunMachine::getAVGFree(int type)
{
	double minA = ((double)freeCPU_A + freeMemory_A) / 2.0;
	double minB = ((double)freeCPU_B + freeMemory_B) / 2.0;
	if (type == 1)return minA;
	else if (type == 2)return minB;
	else return std::min(minA, minB);
}

std::string RunMachine::getName()
{
	return std::string(this->name);
}
