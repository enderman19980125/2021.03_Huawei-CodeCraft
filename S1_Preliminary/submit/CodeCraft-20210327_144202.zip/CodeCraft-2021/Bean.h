#ifndef Bean
#define Bean
#include <string>
#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <cstring>

class ValueforMoney
{
public:
	ValueforMoney() :VMindex(0), perfectNum(0), singleMoney(0) {};
	ValueforMoney(int a, int b, double c) :VMindex(a), perfectNum(b), singleMoney(c) {}; // VMinde perfectnum
	int VMindex;
	int perfectNum;
	double singleMoney;
};

class Machine
{
public:
	Machine();
	Machine(char*, int, int, int, int);
	friend std::ostream& operator << (std::ostream& os, const Machine& m);
	friend std::istream& operator >> (std::istream& is, Machine& m);
	static Machine* build(std::string &s);
	double cpuPri();
	double memoryPri();
	int getRunMoney();
	int getCpuNum();
	int getMemoryNum();
	std::pair<int, int> getCpuMemory();
	int getMoney();
	int emptyIsOk(std::pair<int, int>&&);
	std::string getName();
	int getID();
	void setID(int);


private:
	char name[21];
	int cpuNum;
	int memoryNum;
	int money;
	int runMoney;
	int ID;
};

class VM
{
public:
	VM();
	VM(char*, int, int, int);
	friend std::ostream& operator << (std::ostream& os, const VM& m);
	friend std::istream& operator >> (std::istream& is,VM& m);
	static VM* build(std::string& s);
	double cpuPri();
	double memoryPri();
	double getCoef();
	int getDouble();
	std::pair<int, int> getCpuMemory();
	std::string getName();

private:
	char name[21];
	int cpuNum;
	int memoryNum;
	int isDouble;
};

class Request
{
public:
	Request();
	Request(char*, int, int, int);
	friend std::ostream& operator << (std::ostream& os, const Request&);
	friend std::istream& operator >> (std::istream& is, Request&);
	static Request* build(std::string&);
	//double cpuPri();
	//double memoryPri();
	int getVMIndex();
	int setVMIndex(int);
	int isDouble();
	int getCategory();
	int getSum();
	double getSpace();
	void setIsReal();
	int getIsReal();
	int getMachineID();
	void setMachineID(int);
	int getID();
	double getCoef();
	void setType(int);
	int getType();
	int getDel();
	void setDel();
	void setPerfectNum(int);
	int getPerfectNum();
	std::pair<int, int> getCpuMemory();

private:
	char VMName[21];
	int category;  // 0 add 1 del
	int VMIndex;
	int ID;
	int isReal;
	int MachineID = -1;
	int type = 0;
	int Double;
	int del = 0;
	int perfectNum = 0;
};

class RunMachine
{
public:
	RunMachine();
	RunMachine(Machine*);
	friend std::ostream& operator << (std::ostream& os, const RunMachine& m);
	//friend std::istream& operator >> (std::istream& is, RunMachine& m);
	static RunMachine* build(Machine*);
	//double cpuPri();
	//double memoryPri();
	//std::pair<int, int> getCpuMemory();
	int getRunMoney();
	int getMoney();
	int IsOk(Request*&);
	int update(Request* &);
	int update(Request*, int);
	void Delete(Request*, int);
	int getCPUMemorySum();
	double getResourceSortCoef();
	double getSapceResourceSortCoef();
	void mySort();
	int getOld();
	std::pair<int, Request*> getVMByIndex(int);
	std::pair<int, Request*> getVMByID(int);
	void setOld();
	int getID();
	std::pair<int, int>getABfree();
	void setID(int);
	int getRunNums();
	int getMin();
	void clear();
	int getperfetctNum();
	void setperfetctNum(int pvm);
	void setReal(int);
	double getAVGFree(int type);
	std::string getName();


private:
	char name[21];
	int cpuNum;
	int memoryNum;
	int money;
	int runMoney;
	int freeCPU_A;
	int freeMemory_A;
	int freeCPU_B;
	int freeMemory_B;
	int old;
	int ID = 0x7fffffff;
	int perfetctNum;
	std::vector<std::pair<int,Request*>>RunningVM;
};

#include "FileHundle.h"
#endif
