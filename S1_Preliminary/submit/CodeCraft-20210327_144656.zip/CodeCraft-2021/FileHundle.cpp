#include "FileHundle.h"

void creatMap();
int MachineNum;
int VMNum;
int DataNum;
int buffMachine;
Machine* buffM;

std::vector<Machine*>Machines;
std::vector<VM*> VMs;
std::map<int, int>lessestMoneyMachine;
std::map<int, int>perfectVMNUm;
std::vector<std::vector<Request*>> Requests;
std::vector<Machine*>* cpuOrderMachines;
std::vector<Machine*>* memoryOrderMachines;
std::vector<VM*>* cpuOrderVMs;
std::vector<VM*>* memoryOrderVMs;

std::map<std::string, int>MachineName2Index;
std::map<int, std::string>Index2MachineName;
std::map<std::string, int>VMName2Index;
std::map<int, std::string>Index2VMName;
std::vector<std::vector<RunMachine*>>perfecRuns;
std::vector<std::vector<int>>afterMaxNums;
std::map<int,int>liveTime;
std::vector<std::vector<ValueforMoney *> >Value;
std::map<int, std::pair<int,int>>startEndTime;


int Hundle(std::istream &in) {
	VMs.reserve(10000);

	std::string temp;
	in >> MachineNum;
	Machines.resize(MachineNum);
	in.ignore(1, '\n');
	for (int i = 0; i < MachineNum; i++) {
		getline(in, temp);
		Machines[i] = Machine::build(temp);
	}
	cpuOrderMachines = cpuOrder(Machines);
	memoryOrderMachines = memoryOrder(Machines);
	in >> VMNum;
	VMs.resize(VMNum);
	in.ignore(1, '\n');
	for (int i = 0; i < VMNum; i++) {
		getline(in, temp);
		VMs[i] = VM::build(temp);
	}
	cpuOrderVMs = cpuOrder(VMs);
	memoryOrderVMs = memoryOrder(VMs);
	creatMap();
#if 1
	in >> DataNum;
	in.ignore(1, '\n');
	int applys;
	Requests.resize(DataNum);
	for (int i = 0; i < DataNum; i++) {
		in >> applys;
		in.ignore(1, '\n');
		Requests[i] = std::vector<Request*>(applys);
		for (int j = 0; j < applys; j++) {
			getline(in, temp);
			Requests[i][j] = Request::build(temp);
		}
	}
	perfecRuns.resize(VMNum);
	for (auto& it : perfecRuns)
		it.reserve(5000);
	//in.ignore(std::numeric_limits<std::streamsize>::max(),'\n');
	//if (!in.eof()) exit(-1);
#endif
	analys();
	//buffM = Machines[buffMachine];
	return 0;
}

void creatMap() {
	for (int i = 0; i < MachineNum; i++) {
		MachineName2Index[Machines[i]->getName()] = i;
		Index2MachineName[i] = Machines[i]->getName();
	}
	for (int i = 0; i < VMNum; i++) {
		VMName2Index[VMs[i]->getName()] = i;
		Index2VMName[i] = VMs[i]->getName();
	}
	Value.resize(MachineNum);
	for (auto& it : Value)
		it.resize(VMNum);
	for (int i = 0; i < VMNum; i++) {
		auto money = 0x7fffffff, temp = 0, perfectum = 0;
		auto&& vp = VMs[i]->getCpuMemory();
		if (vp.second == 0) {
			std::cout << "error\n";
		}
		for (int j = 0; j < MachineNum; j++) {
			std::pair<int, int>&& p = Machines[j]->getCpuMemory();
			p.first /= 2;
			p.second /= 2;
			temp = std::min(p.first / vp.first, p.second / vp.second);
			if (!VMs[i]->getDouble())
			{
				temp *= 2;
			}
			perfectum = temp;
			if (temp)
				temp = Machines[j]->getMoney() / temp; // ����С��
			else temp = 0x7fffffff;
			if (temp < money) {
				money = temp;
				perfectVMNUm[i] = perfectum;
				lessestMoneyMachine[i] = j;
			}
		}
	}
	for (int i = 0; i < MachineNum; i++) {
		std::pair<int, int>&& p = Machines[i]->getCpuMemory();
		p.first /= 2;
		p.second /= 2;
		for (int j = 0; j < VMNum; j++) {
			auto money = 0x7fffffff, perfectum = 0;
			auto&& vp = VMs[j]->getCpuMemory();
			perfectum = std::min(p.first / vp.first, p.second / vp.second);
			if (!VMs[j]->getDouble())
			{
				perfectum *= 2;
			}
			double temp = 0;
			if (perfectum)
				temp = (double)Machines[i]->getMoney() / perfectum; // ����С��
			else temp = 0x7fffffff;
			Value[i][j] = new ValueforMoney(j, perfectum, temp);
		}
		std::sort(Value[i].begin(), Value[i].end(), [](ValueforMoney* lcs, ValueforMoney* rcs) {return lcs->singleMoney < rcs->singleMoney; });
	}
	int temp = 0x7fffffff;
	int index = -1;
	for (int i = 0; i < MachineNum; i++) {
		if (Value[i][VMNum - 1]->singleMoney < temp) {
			temp = Value[i][VMNum - 1]->singleMoney;
			index = i;
		}
	}
	buffMachine = index;
}

int getVMName2Index(std::string &s) {
	return VMName2Index[s];
}
int getVMName2Index(std::string &&s) {
	return VMName2Index[s];
}

void analys() {
	std::vector<int>daily(VMNum, -1);
	std::vector<int>delayDelete;
	std::map<int, int>ID2VMIndex;
	afterMaxNums.resize(DataNum);
	Request* r;
	for (auto& it : afterMaxNums)
		it.resize(VMNum, 0);
	for (int i = 0; i < DataNum; i++) {
		if (i) {
			for (int j = 0; j < VMNum; j++)
				afterMaxNums[i][j] = afterMaxNums[i - 1][j];
		}
		for (auto it : delayDelete) {
			afterMaxNums[i][it]--;
		}
		delayDelete.clear();
		for (int j = 0; j < Requests[i].size(); j++) {
			r = Requests[i][j];
			if (r->getCategory()) {
				delayDelete.push_back(ID2VMIndex[r->getID()]);
				startEndTime[r->getID()].second = i;
			}
			else {
				startEndTime[r->getID()] = std::make_pair(i, DataNum);
				ID2VMIndex[r->getID()] = r->getVMIndex();
				afterMaxNums[i][r->getVMIndex()]++;
			}
		}

	}
	for (int i = 0; i < DataNum; i++) {
		for (int j = 0; j < Requests[i].size(); j++) {
			if (!Requests[i][j]->getCategory()) {
				auto id = Requests[i][j]->getID();
				liveTime[id] = startEndTime[id].second - startEndTime[id].first;
			}
		}
	}
	for (int i = DataNum-1; i >= 0; i--) {
		for (int j = 0; j < VMNum; j++) {
			daily[j] = std::max(afterMaxNums[i][j], daily[j]);
			afterMaxNums[i][j] = daily[j];
		}
	}
}
