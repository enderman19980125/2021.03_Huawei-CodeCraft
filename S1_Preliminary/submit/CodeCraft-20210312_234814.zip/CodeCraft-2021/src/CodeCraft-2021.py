import data
import data_io
import simulations


def g():
    for i in range(5):
        yield i


def main():
    data_io.read_data()
    simulations.start()
    data_io.write_data()


if __name__ == "__main__":
    main()
