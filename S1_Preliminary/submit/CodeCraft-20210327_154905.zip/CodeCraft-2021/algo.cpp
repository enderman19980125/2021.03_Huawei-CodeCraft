#include "algo.h"

int nowRealMachinesNum = 0;
int nowday = 0;

std::map<int, std::pair<int, int>>VMID2RunerMachineID;  
std::vector<std::pair<int,std::pair<int,int>>>moveID;
std::vector<std::pair<int, int>>moveSD;
std::vector<RunMachine*>Runs;
std::vector<RunMachine*>cRuns;
std::vector<RunMachine*>buff;
std::vector<RunMachine*>delFlag;
std::map<int, int>moved;
std::map<int, RunMachine*>vDelete;


Machine* findMinforVM(Request* r) {//��ÿ��VMѰ�����ٻ��ѵĻ���
	return Machines[lessestMoneyMachine[r->getVMIndex()]];
#if 0
	double coefficient = 1.0; //memory/cpu  <2 cpu����  >2 memory����
	double thisCoef = r->getCoef();
	std::vector<Machine*> T = *cpuOrderMachines;
	if (thisCoef <= coefficient) {
		for (int i = 0; i < MachineNum; i++) {
			if (T[i]->emptyIsOk(r->getCpuMemory()))
				return T[i];
		}
	}
	else {
		T = *memoryOrderMachines;
		for (int i = 0; i < MachineNum; i++) {
			if (T[i]->emptyIsOk(r->getCpuMemory()))
				return T[i];
		}
	}
#endif
	return NULL;
}

Machine* findMinforVM_2(Request* r) {//��ÿ��VMѰ�����ٻ��ѵĻ���
	int maxN = 1;
	//if (VMNum == 800) maxN = 3;
	int temp = 1;
	Machine* result = NULL;
	for (int i = 0; i < Machines.size();i++) {
		auto& it = Machines[i];
		if (it->emptyIsOk(r->getCpuMemory())) {
			if (temp>=maxN)
				return it;
			result = it;
			temp++;
		}
	}
	return result;
}

Machine* findMinforVM_3(std::vector<Request*>& rs, int start) {//��ÿ��VMѰ�����ٻ��ѵĻ���
	Machine* result = NULL;
	int num = rs.size();
	int maxNum = -1, tempNum = 0;
	for (auto it : Machines) {
		tempNum = 0;
		auto run = RunMachine::build(it);
		for (int i = start; i < num; i++) {
			if (run->update(rs[i]))
				tempNum++;
		}
		if (tempNum > maxNum) {
			result = it;
			maxNum = tempNum;
		}
		else if (tempNum == maxNum) {
			if (result->getMoney() > it->getMoney())
				result = it;
		}
	}
	return result;
}

void addRequest(std::vector<Request*>& rs) {
	auto cpyRuns = Runs;
	for (auto r : rs) {
#ifdef debug__
		//std::cout << run->getRunNums() << std::endl;
		if (r->getID()== 74976758) 
			std::cout << *r << std::endl;
#endif // __debug__
		Machine* minMachine = findMinforVM(r);
		RunMachine* run = RunMachine::build(minMachine);
		run->update(r);
#ifdef debug__
		std::cout << run->getRunNums() << std::endl;
		//if (run->getRunNums() == 0) std::cout << *r << std::endl;
#endif // __debug__

		cpyRuns.push_back(run);
	}
	mergeVirtual(cpyRuns);
	virtual2real(cpyRuns);
}

void addRequest_2(std::vector<Request*>& rs) {
	int virtualID = 0x7fffff; //�������ID
	std::vector<RunMachine*>cpyRuns = Runs;
	std::map<int, RunMachine*>mID2Runing;
	std::vector<Request*> tempvms;
	int type;
	for (auto r : rs) {
#ifdef debug__
		//std::cout << run->getRunNums() << std::endl;
		if (r->getID() == 74976758)
			std::cout << *r << std::endl;
#endif // __debug__
		Machine* minMachine = findMinforVM(r);
		RunMachine* run = RunMachine::build(minMachine);
		type = run->update(r);
		run->setID(virtualID);
		r->setMachineID(virtualID);
		r->setType(type);
		mID2Runing[virtualID] = run;
		virtualID++;
		tempvms.push_back(r);
#ifdef debug__
		std::cout << run->getRunNums() << std::endl;
		//if (run->getRunNums() == 0) std::cout << *r << std::endl;
#endif // __debug__

		cpyRuns.push_back(run);
	}
	mergeVirtual_2(cpyRuns, tempvms, mID2Runing);
	virtual2real(cpyRuns);
}

int insert_request(Request* r) { // 0 no buy 1 buy new
	auto temp = r->getVMIndex();
	int maxN = getMaxnum(perfecRuns[temp]);
	int nowR = getRunningnum(perfecRuns[temp]);
	if (nowR >= maxN) return 1;
	int flag = 1;
	for (int i = 0; i < perfecRuns[temp].size(); i++) {
		auto runM = perfecRuns[temp][i];
		auto type = runM->update(r);

		if (type) {
			flag = 0;
			r->setType(type);
			r->setMachineID(runM->getID());
			r->setIsReal();
			VMID2RunerMachineID[r->getID()] = std::make_pair(runM->getID(), type);

			break;
		}
	}

	return flag;
}

int find_pause(Request* r, std::vector<std::vector<RunMachine*>>& pauseRunMachine) {
	auto temp = r->getVMIndex();
	int lessMoneyNum = lessestMoneyMachine[temp];
	int maxN = perfectVMNUm[temp];
	int flag = temp;
	for (int i = 0; i <pauseRunMachine[temp].size(); i++) {
		auto runM = pauseRunMachine[temp][i];
		if (runM->getRunNums() >= maxN) continue;
		auto type = runM->update(r);
		flag = -1;
		r->setType(type);
		r->setMachineID(runM->getID());
		break;
	}
	return flag;
}

int insert_request_2(Request* r) { // 0 no buy 1 buy new
	int num = Runs.size();
	int maxNum = 1;
	int temNum = 0;
	int tempOk = -1;
	int flag = 1;
	for (int i = 0; i <num; i++) {
		auto runM = cRuns[i];

		if (runM->IsOk(r)) {
			temNum++;
			if (temNum >= maxNum) {
				auto type = runM->update(r);
				if (type) {
					flag = 0;
					tempOk = i;
					r->setType(type);
					r->setMachineID(runM->getID());
					r->setIsReal();
					VMID2RunerMachineID[r->getID()] = std::make_pair(runM->getID(), type);
					return flag;
				}
			}
		}
	}
	if (!flag) {
		auto type = cRuns[tempOk]->update(r);
		r->setType(type);
		r->setMachineID(cRuns[tempOk]->getID());
		r->setIsReal();
		VMID2RunerMachineID[r->getID()] = std::make_pair(cRuns[tempOk]->getID(), type);
	}
	return flag;
}

int find_pause_2(Request* r, std::vector<RunMachine*>& pauseRunMachine) {
	int flag = 1;
	int maxNum = 1;
	int temNum = 0;
	for (int i = 0; i < pauseRunMachine.size(); i++) {
		auto runM = pauseRunMachine[i];
		if (runM->IsOk(r)) {
			temNum++;
			if (temNum >= maxNum) {
				auto type = runM->update(r);
				if (type) {
					flag = -1;
					r->setType(type);
					r->setMachineID(runM->getID());
					VMID2RunerMachineID[r->getID()] = std::make_pair(runM->getID(), type);
					break;
				}
			}
		}
	}
	return flag;
}

void virtual2real_2(std::vector<RunMachine*>&tempRuns, std::vector<int>&tempRunsVMindex) {
	int len = tempRuns.size();
	std::vector<std::string>result;
	Request* r;
	RunMachine* runMachine;
	int type;
	std::map<std::string, int>filter;
	for (int i = 0; i < len; i++) {
		if (tempRuns[i]->getRunNums())
			filter[tempRuns[i]->getName()]++;
	}
	for (auto& it : filter) {
		result.push_back(str_format("(%s, %d)", &(it.first)[0], it.second));
		int temp = it.second;
		it.second = nowRealMachinesNum;
		nowRealMachinesNum += temp;
	}

	for (int i = 0; i < len; i++) {
		runMachine = tempRuns[i];
		if (runMachine->getRunNums()) {
			runMachine->setOld();
			for (int j = 0; j < runMachine->getRunNums(); j++) {
				type = runMachine->getVMByIndex(j).first;
				r = runMachine->getVMByIndex(j).second;
				r->setIsReal();
				r->setMachineID(filter[runMachine->getName()]);
				VMID2RunerMachineID[r->getID()] = std::make_pair(filter[runMachine->getName()], type);
			}
			runMachine->setID(filter[runMachine->getName()]++);
			Runs.push_back(runMachine);
			perfecRuns[tempRunsVMindex[i]].push_back(runMachine);
			//sprintf(name,"(%s, 1)", &(rm[i]->getName())[0]);
		}
		else delete runMachine;// �ڴ��ͷ�
	}
	std::cout << str_format("(purchase, %d)\n", result.size());
	for (auto it : result)
		std::cout << it << std::endl;
}

void virtual2real_3(std::vector<RunMachine*>& tempRuns, std::vector<int>& tempRunsVMindex, std::vector<RunMachine*>& tempBuff) {
	int len = tempRuns.size();
	std::vector<std::string>result;
	Request* r;
	RunMachine* runMachine;
	int type;
	std::map<std::string, int>filter;
	for (int i = 0; i < len; i++) {
		if (tempRuns[i]->getRunNums())
			filter[tempRuns[i]->getName()]++;
	}
	for (auto it : tempBuff) {
		filter[it->getName()]++;
	}
	for (auto& it : filter) {
		result.push_back(str_format("(%s, %d)", &(it.first)[0], it.second));
		int temp = it.second;
		it.second = nowRealMachinesNum;
		nowRealMachinesNum += temp;
	}

	for (int i = 0; i < len; i++) {
		runMachine = tempRuns[i];
		if (runMachine->getRunNums()) {
			runMachine->setOld();
			for (int j = 0; j < runMachine->getRunNums(); j++) {
				type = runMachine->getVMByIndex(j).first;
				r = runMachine->getVMByIndex(j).second;
				r->setIsReal();
				r->setMachineID(filter[runMachine->getName()]);
				VMID2RunerMachineID[r->getID()] = std::make_pair(filter[runMachine->getName()], type);
			}
			runMachine->setID(filter[runMachine->getName()]++);
			Runs.push_back(runMachine);
			perfecRuns[tempRunsVMindex[i]].push_back(runMachine);
			//sprintf(name,"(%s, 1)", &(rm[i]->getName())[0]);
		}
		else delete runMachine;// �ڴ��ͷ�
	}
	for (int i = 0; i < tempBuff.size(); i++) {
		runMachine = tempBuff[i];
		if (runMachine->getRunNums()) {
			runMachine->setOld();
			for (int j = 0; j < runMachine->getRunNums(); j++) {
				type = runMachine->getVMByIndex(j).first;
				r = runMachine->getVMByIndex(j).second;
				r->setIsReal();
				r->setMachineID(filter[runMachine->getName()]);
				VMID2RunerMachineID[r->getID()] = std::make_pair(filter[runMachine->getName()], type);
			}
			runMachine->setID(filter[runMachine->getName()]++);
			Runs.push_back(runMachine);
			buff.push_back(runMachine);
			//sprintf(name,"(%s, 1)", &(rm[i]->getName())[0]);
		}
		else delete runMachine;// �ڴ��ͷ�
	}
	std::cout << str_format("(purchase, %d)\n", result.size());
	for (auto it : result)
		std::cout << it << std::endl;
}

void addRequest_3(std::vector<Request*>& rs) {
	int virtualID = 0x7fffff; //�������ID
	std::vector<std::vector<RunMachine*>>pauseRunMachine(VMNum);
	std::vector<Request*> tempvms;
	std::vector<RunMachine*>tempRuns;
	std::vector<int>tempRunsVMindex;
	std::map<int, RunMachine*>tempID2RunMachine;
	int type;
	for (auto r : rs) {

		if (!insert_request(r)) continue;

		auto temp = find_pause(r, pauseRunMachine);

		if (temp != -1) {
			Machine* minMachine = findMinforVM(r);
			RunMachine* run = RunMachine::build(minMachine);
			run->setperfetctNum(perfectVMNUm[temp]);
			pauseRunMachine[temp].push_back(run);
			tempRuns.push_back(run);
			tempRunsVMindex.push_back(temp);
			type = run->update(r);
			run->setID(virtualID);
			r->setMachineID(virtualID);
			r->setType(type);
			tempID2RunMachine[virtualID] = run;
			virtualID++;
		}
		tempvms.push_back(r);

	}

	virtual2real_2(tempRuns, tempRunsVMindex);

}

void addRequest_4(std::vector<Request*>& rs) {
	int virtualID = 0x7fffff; //�������ID
	std::vector<std::vector<RunMachine*>>pauseRunMachine(VMNum);
	std::vector<Request*> tempvms;
	std::vector<RunMachine*>tempRuns;
	std::vector<RunMachine*>tempBuff;
	std::vector<int>tempRunsVMindex;
	std::map<int, RunMachine*>tempID2RunMachine;
	int type;
	for (auto r : rs) {
		if (liveTime[r->getID()] > 10) {
			if (!insert_request(r)) continue;
			auto temp = find_pause(r, pauseRunMachine);
			if (temp != -1) {
				Machine* minMachine = findMinforVM(r);
				RunMachine* run = RunMachine::build(minMachine);
				run->setperfetctNum(perfectVMNUm[temp]);
				pauseRunMachine[temp].push_back(run);
				tempRuns.push_back(run);
				tempRunsVMindex.push_back(temp);
				type = run->update(r);
				run->setID(virtualID);
				r->setMachineID(virtualID);
				r->setType(type);
				tempID2RunMachine[virtualID] = run;
				virtualID++;
			}
			tempvms.push_back(r);
		}
		else {
			int flag = 1;
			for (auto it : buff) {
				auto type = it->update(r);
				if (type) {
					flag = 0;
					r->setType(type);
					r->setMachineID(it->getID());
					r->setIsReal();
					VMID2RunerMachineID[r->getID()] = std::make_pair(it->getID(), type);
					break;
				}
			}
			for (auto it : tempBuff) {
				auto type = it->update(r);
				if (type) {
					flag = 0;
					r->setType(type);
					break;
				}
			}
			if (flag) {
				Machine* minMachine = Machines[buffMachine];
				RunMachine* run = RunMachine::build(minMachine);
				auto type = run->update(r);
				if (!type) {
					std::cout << "error in buff\n";
					exit(0);
				}
				tempBuff.push_back(run);
				r->setType(type);
			}
		}
	}

	virtual2real_3(tempRuns, tempRunsVMindex, tempBuff);
}

void addRequest_5(std::vector<Request*>& rs, std::vector<RunMachine*>& pauseRunMachine,int & virtualID) {
	//cRuns = Runs;
	std::sort(rs.begin(), rs.end(), [](Request* les, Request* res) {
		//if (les->isDouble() == res->isDouble())
		//	return les->getSpace() > res->getSpace();
		//else return les->isDouble() > res->isDouble();
		return les->getSpace() > res->getSpace();
		//if (liveTime[ls->getID()] && liveTime[rs->getID()])
		//	return ls->getSpace() > rs->getSpace();
		//else
		//	return liveTime[ls->getID()] > liveTime[rs->getID()];
		});
	//std::sort(cRuns.begin(), cRuns.end(), [](RunMachine* les, RunMachine* res) {
	//	return les->getCPUMemorySum() < res->getCPUMemorySum();
	//	});
	//std::sort(pauseRunMachine.begin(), pauseRunMachine.end(), [](RunMachine* ls, RunMachine* rs) {
	//	return ls->getCPUMemorySum() < rs->getCPUMemorySum();
	//	});
	//ResourceSort(Runs);
	int type;
	for (int i = 0; i < rs.size();i++) {
		auto r = rs[i];
		//if (r->getID() == 266880870) {
		//	std::cout << "this\n";
		//}
		//ResourceSort(Runs);
		if (!insert_request_2(r)) continue;
		auto temp = find_pause_2(r, pauseRunMachine);

		if (temp != -1) {
			Machine* minMachine = findMinforVM_2(r);
			RunMachine* run = RunMachine::build(minMachine);
			pauseRunMachine.push_back(run);
			type = run->update(r);
			run->setID(virtualID);
			r->setMachineID(virtualID);
			r->setType(type);
			VMID2RunerMachineID[r->getID()] = std::make_pair(run->getID(), type);
			virtualID++;
		}
	}
}

void deleteRequest(std::vector<Request*>& rs) {
	IDSort(Runs);
	for (auto r : rs) {
		auto p = VMID2RunerMachineID[r->getID()];

#ifdef debug__
		if (it == -1 || vms[it]->getID() != r->getID()) std::cout << "error in delete\n";
#endif // __debug__

		Runs[p.first]->Delete(r, p.second);
		//VMID2RunerMachineID[r->getID()] = std::make_pair(-1, -1);  //�ϸ�ɾ��

	}
}

void deleteRequest_2(std::vector<Request*>& rs, std::vector<RunMachine*> &pauseRunMachine) {
	//IDSort(Runs);
	//IDSort(pauseRunMachine);
	for (auto r : rs) {
		auto p = VMID2RunerMachineID[r->getID()];

#ifdef debug__
		if (it == -1 || vms[it]->getID() != r->getID()) std::cout << "error in delete\n";
#endif // __debug__
		if (p.first >= 100000) {
			pauseRunMachine[p.first - 100000]->Delete(r, p.second);
			vDelete[r->getID()] = pauseRunMachine[p.first - 100000];
		}
		else {
			Runs[p.first]->Delete(r, p.second);
			delFlag.push_back(Runs[p.first]);
		}
		//VMID2RunerMachineID[r->getID()] = std::make_pair(-1, -1);  //�ϸ�ɾ��

	}
}


void hundleRequest(std::vector<Request*>& rs) {
	move_4();
	std::vector<Request*> addR, delR;
	auto it = rs.begin(), e = rs.end();
	for (it; it != e; it++) {
		if ((*it)->getCategory())
			delR.push_back(*it);
		else break;
	}
	deleteRequest(delR);
	delR.clear();
	for (it; it != e; it++) {
		if ((*it)->getCategory())
			delR.push_back(*it);
		else
			addR.push_back(*it);
	}
	//addRequest(addR);
	addRequest_3(addR);

#ifdef __debug__
	for (int i = 0; i < VMNum; i++) {
		auto n = getRunningnum(perfecRuns[i]);
		if (n > afterMaxNums[nowday][i]) {
			std::cerr << "error in line: " << __LINE__ <<str_format(" run num:%d index:%d aferMax:%d",n,i,afterMaxNums[nowday][i])<< std::endl;
			exit(0);
		}
	}
	//std::cout << VMID2RunerMachineID[409440991].first<<" "<< VMID2RunerMachineID[409440991].second << std::endl;
	//disPlayRunning(Runs);
#endif // __debug__

	deleteRequest(delR);
#ifdef debug__
	moveID.push_back(0);
	moveID.push_back(5);
	moveID.push_back(1);

#endif // __debug__

	std::cout << str_format("(migration, %d)\n", moveID.size());

	for (auto &it : moveID) {
		if (it.second.second == 3) {
			std::cout << str_format("(%d, %d)\n", it.first, it.second.first);
		}
		else {
			std::cout << str_format("(%d, %d, %s)\n", it.first, it.second.first, it.second.second == 1 ? "A" : "B");
		}
	}
}

void sub_hundleRequest_2(std::vector<Request*>& rs, std::vector<RunMachine*> &pauseRunMachine,int& vID) {

	std::vector<Request*> addR, delR;
	auto it = rs.begin(), e = rs.end();
	while (it != e) {
		for (it; it != e; it++) {
			if ((*it)->getCategory())
				delR.push_back(*it);
			else break;
		}
		deleteRequest_2(delR, pauseRunMachine);
		delR.clear();
		for (it; it != e; it++) {
			if (!(*it)->getCategory())
				addR.push_back(*it);

			else
				break;
		}
		addRequest_5(addR, pauseRunMachine, vID);
		addR.clear();
	}
}

std::map<int,int> sub_addRequest_5(std::vector<Request*>& rs) {
	cRuns = Runs;
	std::sort(rs.begin(), rs.end(), [](Request* les, Request* res) {
		//if (les->isDouble() == res->isDouble())
		//	return les->getSpace() > res->getSpace();
		//else return les->isDouble() > res->isDouble();
		return les->getSpace() > res->getSpace();
		});
	std::sort(cRuns.begin(), cRuns.end(), [](RunMachine* les, RunMachine* res) {
		return les->getCPUMemorySum() < res->getCPUMemorySum();
		});
	int type;
	std::map<int, int> result;
	for (int i = 0; i < rs.size(); i++) {
		auto r = rs[i];
		if (!insert_request_2(r)) { // �Ѳ���
			result[r->getID()] = 1;
		};
	}
	return result;
}


void hundleRequest_2(std::vector<Request*>& rs) {
	std::vector<RunMachine*> pauseRunMachine;
	std::vector<Request*> temp;
	std::vector<Request*> ttemp;
	std::map < int, int>zero_day;
	int vID = 100000;
	IDSort(Runs);
	if (nowday & 1)
		move_6();
	std::vector<Request*> addR, delR;

	for (auto it : rs) {
		if (!it->getCategory() && liveTime[it->getID()])
			addR.push_back(it);
	}
	auto inserted = sub_addRequest_5(addR);
	addR.clear();
	for (auto it : rs) {
		if (!it->getCategory() && inserted[it->getID()])
			continue;
		ttemp.push_back(it);
	}
	auto it = ttemp.begin(), e = ttemp.end();
#if 0
	for (it; it != e; it++) {
		if ((*it)->getCategory())
			delR.push_back(*it);
		else break;
	}
	deleteRequest_2(delR, pauseRunMachine);
	delR.clear();
	for (it; it != e; it++) {
		if ((*it)->getCategory())
			delR.push_back(*it);
		else
			addR.push_back(*it);
	}
	//addRequest(addR);
	addRequest_5(addR, pauseRunMachine, vID);
#endif
#if 1
	while (it != e) {
		for (it; it != e; it++) {
			if ((*it)->getCategory())
				if (zero_day[(*it)->getID()])
					temp.push_back(*it);
				else
					delR.push_back(*it);
			else break;
		}
		deleteRequest_2(delR, pauseRunMachine);
		delR.clear();
		for (it; it != e; it++) {
			if (!(*it)->getCategory())
				if (liveTime[(*it)->getID()] > 0)
					addR.push_back(*it);
				else
				{
					zero_day[(*it)->getID()] = 1;
					temp.push_back(*it);
				}
			else
				break;
		}
		addRequest_5(addR, pauseRunMachine, vID);
		addR.clear();
	}
	sub_hundleRequest_2(temp, pauseRunMachine, vID);
#endif
	virtual2real_4(pauseRunMachine);
	for (auto it : vDelete) {
		VMID2RunerMachineID[it.first].first = it.second->getID();
	}
	vDelete.clear();

	std::vector<std::pair<int, std::pair<int, int>>>tmoveID;
	for (int i = 0; i < moveID.size(); i++)
	{
		if (moveSD[i].first == moveSD[i].second) continue;
		tmoveID.push_back(moveID[i]);
	}
	moveID = tmoveID;
	std::cout << str_format("(migration, %d)\n", tmoveID.size());

	for (auto& it : moveID) {
		if (it.second.second == 3) {
			//std::cout << str_format("(%d, %d)\n", it.first, it.second.first);
			std::cout << "(" << it.first << ", " << it.second.first<<")\n";
		}
		else {
			//std::cout << str_format("(%d, %d, %s)\n", it.first, it.second.first, it.second.second == 1 ? "A" : "B");
			std::cout << "(" << it.first << ", " << it.second.first << ", " << (it.second.second == 1 ? "A" : "B") << ")\n";
		}
	}
	if (moveID.size())
		moveID.clear();
}

void mergeVirtual(std::vector<RunMachine*>& rm) {
	std::vector < RunMachine* > temprm, resource;
	temprm = resource = rm;
	MoneySort(temprm);
	ResourceSort(resource);
	int RunMachineNum = rm.size();
	int vmnum;
	int maxLoop = 20; //�ϲ�ѭ�����������
	int flag = 1; //�Ƿ��пɺϲ���
	int type;
	std::vector<std::pair<Request*, int> >delTable;
	while (flag)
	{
		for (int i = RunMachineNum - 1; i >= 0; i--) {
#ifdef __debug__
			//std::cout << "i :" << i << std::endl;
#endif // __debug__
			vmnum = temprm[i]->getRunNums();
			for (int j = 0; j < vmnum; j++) {
				auto p = temprm[i]->getVMByIndex(j);
				auto catagory = p.first;
				auto r = p.second;
				ResourceSort(resource);
				for (int k = 0; k < RunMachineNum; k++) {
#ifdef __debug__
					//std::cout << "k :" << k << std::endl;
#endif // __debug__
					if (temprm[i] == resource[k])continue;   //important
					if (!(resource[k]->getOld()) && (resource[i]->getRunNums() == 0)) continue;
					if (r->getIsReal()) continue;
					if (!optimi(temprm[i], catagory, resource[k], r)) continue;
					type = resource[k]->update(r);
					if (type) {
						delTable.push_back(std::make_pair(r, catagory));
						flag = 1;
						if (resource[k]->getOld()) {
							VMID2RunerMachineID[r->getID()] = std::make_pair(resource[k]->getID(), type);
							r->setIsReal();
						}
						break;
					}
				}
			}
			for (int j = delTable.size() - 1; j >= 0; j--)
				temprm[i]->Delete(delTable[j].first, delTable[j].second);
			delTable.clear();

		}
		flag = 0;
		maxLoop--;
		if (!maxLoop) break;

	}

}

void mergeVirtual_2(std::vector<RunMachine*>& rm, std::vector<Request*>& tempvms, std::map<int, RunMachine*>& mID2Runing) {
	std::vector < RunMachine* > resource;
	resource = rm;
	RunMachine* runMachine;
	SpaceSort(tempvms);
	ResourceSort(resource);
	int RunMachineNum = rm.size();

	int type, start = 0;
	for (Request* it : tempvms) {
		//if (it->getIsReal()) continue;
		runMachine = mID2Runing[it->getMachineID()];
		if (runMachine->getRunNums() > 1) continue;
		auto catagory = it->getType();
		//start = binnarySearch(resource, it);
		for (int i = start; i < RunMachineNum; i++) {
			if (runMachine == resource[i]) continue;
			if (!(resource[i]->getOld()) && (resource[i]->getRunNums() == 0)) continue;
			//if (!optimi(runMachine, catagory, resource[i], it)) continue;
			type = resource[i]->update(it);
			if (type) {
				mID2Runing[it->getMachineID()]->Delete(it, catagory);
				it->setType(type);
				it->setMachineID(resource[i]->getID());
				if (resource[i]->getOld()) {
					VMID2RunerMachineID[it->getID()] = std::make_pair(resource[i]->getID(), type);
					it->setIsReal();
				}
				for (int k = 0; k < RunMachineNum; k++) {
					if (resource[k] == runMachine) {
						if (k <= i) {
							int flag = 0;
							for (int j = k + 1; j < RunMachineNum; j++) {
								if (j == i)flag = 1;
								if (resource[j - 1]->getResourceSortCoef() > resource[j]->getResourceSortCoef()) {
									std::swap(resource[j], resource[j - 1]);
									//std::cout << j << " " << resource[j]->getResourceSortCoef() << " " << resource[j - 1]->getResourceSortCoef() << std::endl;
								}
								else break;
							}
							for (int j = i - 1 - flag; j >= 0; j--) {
								if (resource[j]->getResourceSortCoef() > resource[j + 1]->getResourceSortCoef())
									std::swap(resource[j], resource[j + 1]);
								else break;
							}
						}
						else {
							for (int j = i - 1; j >= 0; j--) {
								//std::cout << j << " " << resource[j]->getResourceSortCoef() << " " << resource[j - 1]->getResourceSortCoef() << std::endl;
								if (resource[j]->getResourceSortCoef() > resource[j + 1]->getResourceSortCoef()) {
									std::swap(resource[j], resource[j + 1]);
									//std::cout << j << " " << resource[j]->getResourceSortCoef() << " " << resource[j - 1]->getResourceSortCoef() << std::endl;
								}
								else break;
							}
							for (int j = k + 1; j < RunMachineNum; j++) {
								if (resource[j - 1]->getResourceSortCoef() > resource[j]->getResourceSortCoef())
									std::swap(resource[j], resource[j - 1]);
								else break;
							}
							break;
						}
					}
				}
#ifdef debug__
				for (int k = 1; k < RunMachineNum; k++) {
					if (resource[k]->getResourceSortCoef() < resource[k - 1]->getResourceSortCoef())
					{
						std::cout << k << " error\n";
						exit(0);
					}
			}
				//std::cout << "success\n";
#endif // debug__
				break;
			}
		}
	}

}


void virtual2real(std::vector<RunMachine*>& rm) {
#ifdef debug__

	int allnum = 0, index = 0;
	for (auto it : rm) {
		allnum += it->getRunNums();
		if (it->getRunNums())
			std::cout << index << *it << std::endl;
		index++;
	}
	std::cout << "rm:" << allnum << std::endl;

#endif // __debug__
	IDSort(rm);
	int len = rm.size();
	int tempNum = nowRealMachinesNum;
	std::vector<std::string>result;
	Request* r;
	int type;
	std::map<std::string, int>filter;
	for (int i = nowRealMachinesNum; i < len; i++) {
		if (rm[i]->getRunNums())
			filter[rm[i]->getName()]++;
	}
	for (auto &it : filter) {
		result.push_back(str_format("(%s, %d)", &(it.first)[0], it.second));
		int temp = it.second;
		it.second = nowRealMachinesNum;
		nowRealMachinesNum += temp;
	}

	for (int i = tempNum; i < len; i++) {

#ifdef __debug__
		if (rm[i]->getOld()) std::cout << "virtual2real error\n";
#endif // __debug__

		if (rm[i]->getRunNums()) {
			rm[i]->setOld();
			for (int j = 0; j < rm[i]->getRunNums(); j++) {
				type = rm[i]->getVMByIndex(j).first;
				r = rm[i]->getVMByIndex(j).second;
				r->setIsReal();
				r->setMachineID(filter[rm[i]->getName()]);
				VMID2RunerMachineID[r->getID()] = std::make_pair(filter[rm[i]->getName()], type);
#ifdef __debug__
				std::cout << r->getID()<<" " << VMID2RunerMachineID[r->getID()].first << std::endl;
#endif // __debug__

			}
			rm[i]->setID(filter[rm[i]->getName()]++);
#ifdef __debug__
			std::cout << rm[i]->getID() << std::endl;
#endif // __debug__
			Runs.push_back(rm[i]);
			//sprintf(name,"(%s, 1)", &(rm[i]->getName())[0]);
		}
		else delete rm[i];// �ڴ��ͷ�
	}
	std::cout << str_format("(purchase, %d)\n", result.size());
	for (auto it : result)
		std::cout << it << std::endl;
}

void virtual2real_4(std::vector<RunMachine*>&rm) {

	int len = rm.size();
	std::vector<std::string>result;
	Request* r;
	int type;
	std::map<std::string, int>filter;
	for (int i = 0; i < len; i++) {
		if (rm[i]->getRunNums())
			filter[rm[i]->getName()]++;
	}
	for (auto& it : filter) {
		result.push_back(str_format("(%s, %d)", &(it.first)[0], it.second));
		int temp = it.second;
		it.second = nowRealMachinesNum;
		nowRealMachinesNum += temp;
	}

	for (int i = 0; i < len; i++) {


		if (true) {
			rm[i]->setOld();
			for (int j = 0; j < rm[i]->getRunNums(); j++) {
				type = rm[i]->getVMByIndex(j).first;

				r = rm[i]->getVMByIndex(j).second;
				//if (r->getID() == 266880870 || r->getID()== 289394300) {
				//	std::cout << "this\n";
				//}
				r->setIsReal();
				r->setMachineID(filter[rm[i]->getName()]);
				VMID2RunerMachineID[r->getID()] = std::make_pair(filter[rm[i]->getName()], type);

			}
			rm[i]->setID(filter[rm[i]->getName()]++);
			Runs.push_back(rm[i]);
			//sprintf(name,"(%s, 1)", &(rm[i]->getName())[0]);
		}
		else delete rm[i];// �ڴ��ͷ�
	}
	std::cout << str_format("(purchase, %d)\n", result.size());
	for (auto it : result)
		std::cout << it << std::endl;
}

int optimi(RunMachine* res, int type,RunMachine* des, Request* r) {
	double tres = res->getAVGFree(type);
	int flag = des->IsOk(r);
	if (flag == 0)return false;
	double tdes = des->getAVGFree(flag);
	double temp = std::max(tres, tdes);
	auto p = (r->getCpuMemory());
	tdes -= ((double)p.first + p.second) / 2.0;
	tres += ((double)p.first + p.second) / 2.0;
	double ttemp = std::max(tres, tdes);
	if (ttemp > temp)return true;
	return false;
}

void output(std::vector<Request*>& rs) {
	for (auto it : rs) {
		if (it->getCategory()) continue;
		auto p = VMID2RunerMachineID[it->getID()].second;
		if (p==3)
			std::cout << str_format("(%d)\n", VMID2RunerMachineID[it->getID()].first);
		else {
			std::cout << str_format("(%d, %s)\n", VMID2RunerMachineID[it->getID()].first, p == 1 ? "A" : "B");
		}
	}
}

void move() {
	moveID.clear();
	int moveNum = 3 * nowRealMachinesNum / 1000; //�ϲ��������
	std::vector < RunMachine* > resource, tempresource;
	tempresource = resource = Runs;
	ResourceSort(tempresource);
	int RunMachineNum = Runs.size();
	int vmnum;
	std::vector<std::pair<Request*, int> >delTable;
	int flag = 1; //�Ƿ��пɺϲ���
	int maxLoop = 20; //�ϲ�ѭ�����������
	int type;
	while (flag)
	{
		for (int i = 0; i < RunMachineNum; i++) {
			vmnum = tempresource[i]->getRunNums();
			for (int j = 0; j < vmnum; j++) {
				auto p = tempresource[i]->getVMByIndex(j);
				auto catagory = p.first;
				auto r = p.second;
				ResourceSort(resource);
				for (int k = 0; k < RunMachineNum; k++) {
					if (tempresource[i] == resource[k])continue;   //important
					if (!optimi(tempresource[i], catagory, resource[k], r)) continue;
					type = resource[k]->update(r);
					if (type) {
						delTable.push_back(std::make_pair(r, catagory));
						flag = 1;
						VMID2RunerMachineID[r->getID()] = std::make_pair(resource[k]->getID(), type);
						moveID.push_back(std::make_pair(r->getID(), std::make_pair(resource[k]->getID(), type)));
						moveNum--;
						if (moveNum <= 0) return;
						break;
					}
				}
			}
			for (int j = delTable.size() - 1; j >= 0; j--)
				tempresource[i]->Delete(delTable[j].first, delTable[j].second);
			delTable.clear();
		}
		flag = 0;
		maxLoop--;
		if (!maxLoop) break;

	}
}

void move_2() {
	moveID.clear();
	int moveNum = 5 * nowRealMachinesNum / 1000; //�ϲ��������
	if (!moveNum) return;
	std::vector < RunMachine* > resource, tempresource;
	IDSort(Runs);
	std::vector<std::pair<Request*, int> >delTable;
	delTable.reserve(100);
	resource = tempresource = Runs;
	ResourceSort(tempresource);
	ResourceSort(resource);
	RunMachine* source, * des;
	int RunMachineNum = Runs.size();
	int vmnum;
	int type, catagory;
	for (int i = RunMachineNum - 1; i >= 0; i--) {
		source = tempresource[i];
		vmnum = source->getRunNums();
		for (int j = 0; j < vmnum; j++) {
			auto p = source->getVMByIndex(j);
			catagory = p.first;
			auto r = p.second;
			if (moved[r->getID()]) continue;
			//ResourceSort(resource);
			for (int k = 0; k < RunMachineNum; k++) {
				des = resource[k];
				if (source == des)continue;   //important
				if (!des->getRunNums()) continue;
				type = des->update(r);
				if (type) {
					delTable.push_back(std::make_pair(r, catagory));
#if 0
					for (int L = k - 1; L >= 0; L--) {
						if (resource[L - 1]->getResourceSortCoef() > resource[L]->getResourceSortCoef()) {
							std::swap(resource[L], resource[L - 1]);
							//std::cout << j << " " << resource[j]->getResourceSortCoef() << " " << resource[j - 1]->getResourceSortCoef() << std::endl;
						}
						else break;
					}
#endif
#ifdef debug__
					for (int L = 1; L < RunMachineNum; L++) {
						if (resource[L]->getResourceSortCoef() < resource[L - 1]->getResourceSortCoef())
						{
							std::cout << L << " error\n";
							exit(0);
						}
					}
					//std::cout << "success\n";
#endif // debug__
					moved[r->getID()] = 1;
					VMID2RunerMachineID[r->getID()] = std::make_pair(des->getID(), type);
					moveID.push_back(std::make_pair(r->getID(), std::make_pair(des->getID(),type)));
					r->setType(type);
					r->setMachineID(des->getID());
					moveNum--;
					if (!moveNum) {
						for (int j = delTable.size() - 1; j >= 0; j--)
							source->Delete(delTable[j].first, delTable[j].second);
						delTable.clear();
						return;
					}
					break;
				}
			}
		}
		for (int j = delTable.size() - 1; j >= 0; j--)
			source->Delete(delTable[j].first, delTable[j].second);
		delTable.clear();
#if 0
		for (int k = 1; k < RunMachineNum; k++) {
			if (resource[k - 1]->getResourceSortCoef() > resource[k]->getResourceSortCoef())
				std::swap(resource[k], resource[k - 1]);
		}
#endif
#ifdef debug__
		for (int L = 1; L < RunMachineNum; L++) {
			if (resource[L]->getResourceSortCoef() < resource[L - 1]->getResourceSortCoef())
			{
				std::cout << L << " error\n";
				exit(0);
			}
		}
		//std::cout << "success\n";
#endif // debug__

	}

}

void move_3() {
	moveID.clear();
	int moveNum = 5 * nowRealMachinesNum / 1000 - 1; //�ϲ��������
	if (!moveNum) return;
	RunMachine* source, * des;
	int vmnum;
	int type, catagory;
	for (int i = 0; i<VMNum ; i++) {
		if (!moveNum) break;
		int maxNum = getMaxnum(perfecRuns[i]);
		int runNum = getRunningnum(perfecRuns[i]);
		int afterMax = afterMaxNums[nowday][i];
		if (runNum >= maxNum)continue;
		runVMNumSort(perfecRuns[i]);
		for (int j = 0; j < perfecRuns[i].size(); j++) {
			if (!moveNum) break;
			source = perfecRuns[i][j];
			vmnum = source->getRunNums();
			//if (maxNum - source->getperfetctNum() < afterMax) break;
			if (maxNum -source->getperfetctNum() < runNum) break;
			if (moveNum - vmnum < 0) break;
			moveNum -= vmnum;
			for (int k = 0; k < vmnum; k++) {
				auto p = source->getVMByIndex(k);
				catagory = p.first;
				auto r = p.second;
				for (int kk = perfecRuns[i].size() - 1; kk >= 0; kk--) {
					if (kk == j) {
						std::cout << "error in move3\n";
						exit(0);
					}
					des = perfecRuns[i][kk];
					type = des->update(r);
					if (type) {

						VMID2RunerMachineID[r->getID()] = std::make_pair(des->getID(), type);
						moveID.push_back(std::make_pair(r->getID(), std::make_pair(des->getID(), type)));
						r->setType(type);
						r->setMachineID(des->getID());
						break;
					}
				}
			}
			maxNum -= source->getperfetctNum();
			source->clear();
		}
		RrunVMNumSort(perfecRuns[i]);
	}

}

void move_4() {
	moveID.clear();
	int moveNum = 5 * nowRealMachinesNum / 1000 - 1; //�ϲ��������
	if (!moveNum) return;
	std::vector<int>noneed;
	std::map<int, int>need;
	std::vector<int>deltable;
	for (int i = 0; i < VMNum; i++) {
		auto maxN = getMaxnum(perfecRuns[i]);
		if (maxN > afterMaxNums[nowday][i])
			noneed.push_back(i);
		else
			need[i] = afterMaxNums[nowday][i] - maxN;
	}
	RunMachine* source, * des;
	int vmnum;
	int type, catagory;
	for (int i = 0; i < noneed.size(); i++) {
		if (!moveNum) break;
		int maxNum = getMaxnum(perfecRuns[noneed[i]]);
		int runNum = getRunningnum(perfecRuns[noneed[i]]);
		int afterMax = afterMaxNums[nowday][noneed[i]];

#ifdef __debug__
		if (runNum > afterMax) {
			std::cerr << "error runNum > afterMax\n";
			exit(0);
		}
#endif // __debug__

		if (runNum >= maxNum)continue;
		runVMNumSort(perfecRuns[noneed[i]]);
		deltable.clear();
		for (int j = 0; j < perfecRuns[noneed[i]].size(); j++) {
			if (!moveNum) break;
			source = perfecRuns[noneed[i]][j];
			vmnum = source->getRunNums();
			if (maxNum - source->getperfetctNum() < afterMax) break;
			if (maxNum - source->getperfetctNum() < runNum) break;
			if (moveNum - vmnum < 0) break;
			moveNum -= vmnum;
			for (int k = 0; k < vmnum; k++) {
				auto p = source->getVMByIndex(k);
				catagory = p.first;
				auto r = p.second;
				for (int kk = perfecRuns[noneed[i]].size() - 1; kk >= 0; kk--) {
					if (kk == j) {
						std::cerr << "error in move4\n";
						exit(0);
					}
					des = perfecRuns[noneed[i]][kk];
					type = des->update(r);
					if (type) {

						VMID2RunerMachineID[r->getID()] = std::make_pair(des->getID(), type);
						moveID.push_back(std::make_pair(r->getID(), std::make_pair(des->getID(), type)));
						r->setType(type);
						r->setMachineID(des->getID());
						break;
					}
				}
			}
			maxNum -= source->getperfetctNum();
			source->clear();
			for (int k = 0; k < VMNum; k++) {
				auto index = Value[MachineName2Index[source->getName()]][k]->VMindex;
				if (need[index] > 0) {
					source->setperfetctNum(Value[MachineName2Index[source->getName()]][k]->perfectNum);
					if (source->getperfetctNum() <= 0) break;
					need[index] -= source->getperfetctNum();
					perfecRuns[index].push_back(source);
					break;
				}
			}
			deltable.push_back(j);//��Ҫ��
		}
		for (int j = deltable.size() - 1; j >= 0; j--) {
			perfecRuns[noneed[i]].erase(perfecRuns[noneed[i]].begin() + deltable[j]);
		}
		RrunVMNumSort(perfecRuns[noneed[i]]);
	}

}

void move_5() {
	moveID.clear();
	int allVMnum = getRunningnum(Runs);
	int moveNum = (5 * allVMnum) / 1000 - 1; //�ϲ��������
	if (moveNum<=0) return;
	std::vector < RunMachine* > resource, tempresource;
	IDSort(Runs);
	std::vector<std::pair<Request*, int> >delTable;
	delTable.reserve(100);
	resource = tempresource = Runs;
	ResourceSort(tempresource);
	ResourceSort(resource);
	RunMachine* source, * des;
	int RunMachineNum = Runs.size();
	int vmnum;
	int maxLeft = -1;
	int type, catagory;
	for (int i = RunMachineNum - 1; i >= 0; i--) {
		if (maxLeft >= i)break;
		source = tempresource[i];
		vmnum = source->getRunNums();
		if (vmnum > moveNum) continue;
		for (int j = 0; j < vmnum; j++) {
			if (maxLeft >= i)break;
			auto p = source->getVMByIndex(j);
			catagory = p.first;
			auto r = p.second;
			//ResourceSort(resource);
			for (int k = 0; k < RunMachineNum; k++) {
				des = resource[k];
				maxLeft = std::max(maxLeft, k);
				if (k >= i)break;  //important
				if (!des->getRunNums()) continue;
				type = des->update(r);
				if (type) {
					delTable.push_back(std::make_pair(r, catagory));
					VMID2RunerMachineID[r->getID()] = std::make_pair(des->getID(), type);
					moveID.push_back(std::make_pair(r->getID(), std::make_pair(des->getID(), type)));
					r->setType(type);
					r->setMachineID(des->getID());
					moveNum--;
					if (moveNum<=0) {
						for (int j = delTable.size() - 1; j >= 0; j--)
							source->Delete(delTable[j].first, delTable[j].second);
						delTable.clear();
						return;
					}
					break;
				}
			}
		}
		for (int j = delTable.size() - 1; j >= 0; j--)
			source->Delete(delTable[j].first, delTable[j].second);
		delTable.clear();

	}

}

void move_6() {
	moved.clear();
	moveID.clear();
	int allVMnum = getRunningnum(Runs);
	int moveNum = (5 * allVMnum) / 1000 - 1; //�ϲ��������
	if (moveNum <= 0) return;
	std::vector < RunMachine* > tempresource(Runs);
	std::vector<std::pair<Request*, int> >delTable;
	delTable.reserve(100);
	/*for (auto it : delFlag) {
		auto p = it->getABfree();
		int moveNode;
		int toNode;
		if (p.first > p.second) moveNode = 1, toNode = 2;
		else moveNode = 2, toNode = 1;
		it->mySort();
		for (int i = 0; i < it->getRunNums(); i++) {
			auto pr = it->getVMByIndex(i);
			auto r = pr.second;
			if (pr.first == moveNode) {
				auto type = it->update(r, toNode);
				if (type) {
					delTable.push_back(std::make_pair(r, moveNode));
					VMID2RunerMachineID[r->getID()] = std::make_pair(it->getID(), type);
					moveID.push_back(std::make_pair(r->getID(), std::make_pair(it->getID(), type)));
					r->setType(type);
					r->setMachineID(it->getID());
					moveNum--;
					if (moveNum <= 0) {
						for (int j = delTable.size() - 1; j >= 0; j--)
							it->Delete(delTable[j].first, delTable[j].second);
						delTable.clear();
						return;
					}
					break;
				}
			}
		}
		for (int j = delTable.size() - 1; j >= 0; j--)
			it->Delete(delTable[j].first, delTable[j].second);
		delTable.clear();
	}*/
	delFlag.clear();
	std::sort(tempresource.begin(), tempresource.end(), [](RunMachine* ls, RunMachine* rs) {
		return ls->getCPUMemorySum() < rs->getCPUMemorySum();
		});

	std::vector < RunMachine* > resource(tempresource);
	/*std::sort(resource.begin(), resource.end(), [](RunMachine* ls, RunMachine* rs) {
		return ls->getCPUMemorySum() < rs->getCPUMemorySum();
		});*/
	RunMachine* source, * des;
	int RunMachineNum = Runs.size();
	int vmnum;
	int type, catagory;
	for (int i = RunMachineNum - 1; i >= 0; i--) {
		source = tempresource[i];
		vmnum = source->getRunNums();
		if (vmnum > moveNum) continue;
		//source->mySort();
		source->mySort();
		for (int j = 0; j < vmnum; j++) {
			auto p = source->getVMByIndex(j);
			catagory = p.first;
			auto r = p.second;
			//if (moved[r->getID()]) {  continue; }
			//if (VMID2RunerMachineID[r->getID()].first != source->getID()) { std::cout << __LINE__; exit(-1111); };
			int flag = 1;
			for (int k = 0; k < RunMachineNum; k++) {
				des = tempresource[k];
				//if (source->getID() == des->getID() && (source != des)) {
				//	std::cout << i << " " << k << " " << source << " " << des << std::endl;
				//	exit(0);
				//}
				if (i == k)continue;
				if (!des->getRunNums()) continue;
				type = des->IsOk(r);
				if (type) {
					des->update(r);

					moved[r->getID()] = 1;
					flag = 0;
					delTable.push_back(std::make_pair(r, catagory));
					VMID2RunerMachineID[r->getID()] = std::make_pair(des->getID(), type);
					moveID.push_back(std::make_pair(r->getID(), std::make_pair(des->getID(), type)));
					moveSD.push_back(std::make_pair(source->getID(), des->getID()));
					r->setType(type);
					r->setMachineID(des->getID());
					moveNum--;
					if (moveNum <= 0) {
						for (int j = delTable.size() - 1; j >= 0; j--)
							source->Delete(delTable[j].first, delTable[j].second);
						delTable.clear();
						return;
					}
					break;
				}
			}
		}
		for (int j = delTable.size() - 1; j >= 0; j--)
			source->Delete(delTable[j].first, delTable[j].second);
		delTable.clear();

	}

}