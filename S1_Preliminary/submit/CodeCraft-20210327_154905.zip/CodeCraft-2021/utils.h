#ifndef utils
#define utils
#include <vector>
#include <algorithm>
#include <cstring>
#include <memory>
#include "Bean.h"

template<typename ... Args>
static std::string str_format(const std::string& format, Args ... args)
{
	auto size_buf = std::snprintf(nullptr, 0, format.c_str(), args ...) + 1;
	std::unique_ptr<char[]> buf(new(std::nothrow) char[size_buf]);

	if (!buf)
		return std::string("");

	std::snprintf(buf.get(), size_buf, format.c_str(), args ...);
	return std::string(buf.get(), buf.get() + size_buf - 1);
}


std::vector<Machine*>* cpuOrder(std::vector<Machine*>&);
std::vector<Machine*>* memoryOrder(std::vector<Machine*>&);
std::vector<VM*>* cpuOrder(std::vector<VM*>&);
std::vector<VM*>* memoryOrder(std::vector<VM*>&);
void MoneySort(std::vector<RunMachine*>&);
void disPlayRunning(std::vector<RunMachine*>&);
void ResourceSort(std::vector<RunMachine*>&);
void IDSort(std::vector<RunMachine*>&);
void IDSort(std::vector<Request*>&);
long long dayCost();
int allMachineMoney();
void SpaceSort(std::vector<Request*>&);
int binnarySearch(std::vector<Request*>&,int);
void spceResourceSort(std::vector<RunMachine*>&);
void RspceResourceSort(std::vector<RunMachine*>&);
int binnarySearch(std::vector < RunMachine* >, Request*);
void runVMNumSort(std::vector<RunMachine*>& m);
void RrunVMNumSort(std::vector<RunMachine*>& m);
int getMaxnum(std::vector<RunMachine*> a);
int getRunningnum(std::vector<RunMachine*> a);

#include "algo.h"
#endif // !utils

#ifndef __debug__
//#define __debug__
#endif // !__debug__