import data
import data_io
import theory
import simulations


def main():
    data_io.read_data()


if __name__ == "__main__":
    main()
