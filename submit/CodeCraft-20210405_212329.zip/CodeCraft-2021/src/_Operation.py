from _VM import SingleVM, DoubleVM
from _Server import Server
from typing import List, Dict, Union, Optional


class VMOperation:
    def __init__(self, day: int, vm: Union[SingleVM, DoubleVM]):
        self.__day = day
        self.__vm = vm

    def get_day(self) -> int:
        return self.__day

    def get_vm(self) -> Union[SingleVM, DoubleVM]:
        return self.__vm


class SingleVMOperation(VMOperation):
    def __init__(self, day: int, vm: SingleVM, server: Optional[Server] = None, node: Optional[str] = None):
        super().__init__(day=day, vm=vm)
        self.__server = server
        self.__node = node

    def get_server(self) -> Optional[Server]:
        return self.__server

    def get_node(self) -> Optional[str]:
        return self.__node

    def set_server(self, server: Server) -> None:
        self.__server = server

    def set_node(self, node: str) -> None:
        self.__node = node


class DoubleVMOperation(VMOperation):
    def __init__(self, day: int, vm: DoubleVM, server: Optional[Server] = None):
        super().__init__(day=day, vm=vm)
        self.__server = server

    def get_server(self) -> Optional[Server]:
        return self.__server

    def set_server(self, server: Server) -> None:
        self.__server = server


class RemoveVMOperation(VMOperation):
    pass


class DeploySingleVMOperation(SingleVMOperation):
    pass


class MigrateSingleVMOperation(SingleVMOperation):
    pass


class RemoveSingleVMOperation(RemoveVMOperation):
    pass


class DeployDoubleVMOperation(DoubleVMOperation):
    pass


class MigrateDoubleVMOperation(DoubleVMOperation):
    pass


class RemoveDoubleVMOperation(RemoveVMOperation):
    pass


class PurchaseServerOperation:
    def __init__(self, day: int, server: Server):
        self.__day = day
        self.__server = server

    def get_day(self) -> int:
        return self.__day

    def get_server(self) -> Server:
        return self.__server


class DayInfo:
    def __init__(self, day: int):
        self.__day = day
        self.__purchase_cost = 0
        self.__running_cost = 0
        self.__running_server_dict = {}
        self.__running_vm_dict = {}
        self.__request_operation_list = []
        self.__purchase_server_operation_list = []
        self.__migrate_vm_operation_list = []

    def get_day(self) -> int:
        return self.__day

    def get_running_server_dict(self) -> Dict[str, Server]:
        return self.__running_server_dict

    def add_running_server(self, server: Server) -> None:
        if server.get_server_id() not in self.get_running_server_dict().keys():
            self.__running_server_dict[server.get_server_id()] = server
            self.__running_cost += server.get_cost_everyday()

    def get_running_vm_dict(self) -> Dict[str, Union[SingleVM, DoubleVM]]:
        return self.__running_vm_dict

    def add_running_vm(self, vm: Union[SingleVM, DoubleVM]) -> None:
        self.__running_vm_dict[vm.get_vm_id()] = vm

    def get_request_operation_list(self) -> List[Union[DeploySingleVMOperation, DeployDoubleVMOperation,
                                                       RemoveSingleVMOperation, RemoveDoubleVMOperation]]:
        return self.__request_operation_list

    def add_request_operation(self, op: Union[DeploySingleVMOperation, DeployDoubleVMOperation,
                                              RemoveSingleVMOperation, RemoveDoubleVMOperation]) -> None:
        self.__request_operation_list.append(op)

    def get_purchase_server_operation_list(self) -> List[PurchaseServerOperation]:
        return self.__purchase_server_operation_list

    def add_purchase_server_operation(self, op: PurchaseServerOperation) -> None:
        self.__purchase_server_operation_list.append(op)
        self.__purchase_cost += op.get_server().get_cost_purchase()

    def get_migrate_vm_operation_list(self) -> List[Union[MigrateSingleVMOperation, MigrateDoubleVMOperation]]:
        return self.__migrate_vm_operation_list

    def add_migrate_vm_operation(self, op: Union[MigrateSingleVMOperation, MigrateDoubleVMOperation]) -> None:
        self.__migrate_vm_operation_list.append(op)

    def get_purchase_cost(self) -> int:
        return self.__purchase_cost

    def get_running_cost(self) -> int:
        return self.__running_cost

    def get_total_cost(self) -> int:
        return self.get_purchase_cost() + self.get_running_cost()
